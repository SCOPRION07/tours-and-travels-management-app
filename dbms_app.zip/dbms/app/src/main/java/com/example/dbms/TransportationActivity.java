package com.example.dbms;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TransportationActivity extends AppCompatActivity {
    private TextView tvPrice, tvDepartureTime, tvArrivalTime, tvPickup, tvDropoff, tvProviderName, tvAvailableSeats;
    private Button btnBookTransportation;
    private double price;
    private int placeId;
    private String providerName;
    private ExecutorService executorService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transportation);

        // Initialize views
        tvPrice = findViewById(R.id.tvPrice);
        tvDepartureTime = findViewById(R.id.tvDepartureTime);
        tvArrivalTime = findViewById(R.id.tvArrivalTime);
        tvPickup = findViewById(R.id.tvPickup);
        tvDropoff = findViewById(R.id.tvDropoff);
        tvProviderName = findViewById(R.id.tvProviderName);
        tvAvailableSeats = findViewById(R.id.tvAvailableSeats);
        btnBookTransportation = findViewById(R.id.btnBookTransportation);

        placeId = getIntent().getIntExtra("place_id", -1);
        Log.d("TransportationActivity", "Received placeId: " + placeId);// Passed from previous activity
        executorService = Executors.newSingleThreadExecutor();
        // Load transportation details from database
        loadTransportationDetails();

        btnBookTransportation.setOnClickListener(v -> {
            if (price > 0 && providerName != null) {
                Intent intent = new Intent(TransportationActivity.this, PaymentActivity.class);
                intent.putExtra("amount", price);
                intent.putExtra("category", providerName);
                startActivity(intent);
            } else {
                Toast.makeText(this, "Unable to book transportation. Try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadTransportationDetails() {
        executorService.execute(() -> {
        try (Connection connection = new connectionclass().conn()) {
            if (connection == null) {
                Log.e("DatabaseConnection", "Connection is null.");
                runOnUiThread(() -> Toast.makeText(this, "Database connection failed.", Toast.LENGTH_SHORT).show());
                return;
            }
            String query = "SELECT * FROM transportation WHERE place_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, placeId); // Use placeId to find hotels
            ResultSet resultSet = statement.executeQuery();
            Log.d("DatabaseQuery", "Executing query: SELECT * FROM transportation WHERE place_id = " + placeId);

            if (resultSet.next()) {
                price = resultSet.getDouble("price");
                String departureTime = resultSet.getString("departure_time");
                String arrivalTime = resultSet.getString("arrival_time");
                String pickup = resultSet.getString("pickup");
                String dropoff = resultSet.getString("dropoff");
                providerName = resultSet.getString("provider_name");
                int availableSeats = resultSet.getInt("available_seats");

                // Update the views with the retrieved data

                runOnUiThread(() -> {
                    tvPrice.setText("Price: ₹" + price);
                    tvDepartureTime.setText("Departure: " + departureTime);
                    tvArrivalTime.setText("Arrival: " + arrivalTime);
                    tvPickup.setText("Pickup: " + pickup);
                    tvDropoff.setText("Dropoff: " + dropoff);
                    tvProviderName.setText("Provider: " + providerName);
                    tvAvailableSeats.setText("Seats: " + availableSeats);
                });
            } else {
                Toast.makeText(this, "No transportation details available.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e("DatabaseError", "Error loading transportation details", e);
            Toast.makeText(this, "Error loading data", Toast.LENGTH_SHORT).show();
        }
    });
    }
}


