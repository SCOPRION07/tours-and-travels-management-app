package com.example.dbms;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PaymentActivity extends AppCompatActivity {
    private Spinner spinnerPaymentMethod;
    private TextView tvAmount, tvCategory;
    private Button btnPay;
    private double amount;
    private String category;
    private ExecutorService executorService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        // Initialize views
        spinnerPaymentMethod = findViewById(R.id.spinnerPaymentMethod);
        tvAmount = findViewById(R.id.tvAmount);
        tvCategory = findViewById(R.id.tvCategory);
        btnPay = findViewById(R.id.btnPay);

        amount = getIntent().getDoubleExtra("amount", 0);
        category = getIntent().getStringExtra("category");

        tvAmount.setText(String.valueOf(amount));
        tvCategory.setText(category);

        // Payment methods setup
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.payment_methods, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPaymentMethod.setAdapter(adapter);

        executorService = Executors.newSingleThreadExecutor();

        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        int userId = sharedPreferences.getInt("user_id", -1);
        // -1 if user_id not found
        btnPay.setOnClickListener(v -> saveTransaction(userId));
//        if (userId != -1) {
//            // Proceed with transaction using userId
//            btnPay.setOnClickListener(v -> saveTransaction(userId));
//        }else {
//            runOnUiThread(() -> Toast.makeText(PaymentActivity.this, "Problem", Toast.LENGTH_SHORT).show());
//        }
    }

    private void saveTransaction(int userId) {
        String paymentMethod = spinnerPaymentMethod.getSelectedItem().toString();
        String status = "Complete";
        long timestamp = System.currentTimeMillis();

        executorService.execute(() -> {
            try (Connection connection = new connectionclass().conn()) {
                String query = "INSERT INTO transaction (user_id, amount, Timestamp, Payment_method, Category, Status) VALUES (?, ?, ?, ?, ?, ?)";
                PreparedStatement statement = connection.prepareStatement(query);
                statement.setInt(1, userId);
                statement.setDouble(2, amount);
                statement.setTimestamp(3, new Timestamp(timestamp));
                statement.setString(4, paymentMethod);
                statement.setString(5, category);
                statement.setString(6, status);

                int rowsAffected = statement.executeUpdate();
                runOnUiThread(() -> {
                    if (rowsAffected > 0) {
                        Toast.makeText(PaymentActivity.this, "Payment successful!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(PaymentActivity.this, "Payment failed. Try again.", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                Log.e("DatabaseError", "Error saving transaction", e);
                runOnUiThread(() -> Toast.makeText(PaymentActivity.this, "Payment error", Toast.LENGTH_SHORT).show());
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executorService.shutdown();
    }
}
