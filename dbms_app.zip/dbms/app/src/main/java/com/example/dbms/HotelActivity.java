package com.example.dbms;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HotelActivity extends AppCompatActivity {
    private TextView tvHotelName, tvHotelId, tvAddress, tvPhoneNo, tvRoomType, tvRate;
    private Button btnPay;
    private int placeId;
    private double rate;
    private ExecutorService executorService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotel);

        // Initialize views
        tvHotelName = findViewById(R.id.tvHotelName);
        tvHotelId = findViewById(R.id.tvHotelId);
        tvAddress = findViewById(R.id.tvAddress);
        tvPhoneNo = findViewById(R.id.tvPhoneNo);
        tvRoomType = findViewById(R.id.tvRoomType);
        tvRate = findViewById(R.id.tvRate);
        btnPay = findViewById(R.id.btnPay);

        placeId = getIntent().getIntExtra("place_id", -1); // Passed from previous activity
        executorService = Executors.newSingleThreadExecutor();

        fetchHotelDetails(); // Fetch details when activity is created

        btnPay.setOnClickListener(v -> {
            Intent intent = new Intent(this, PaymentActivity.class);
            intent.putExtra("amount", rate);
            intent.putExtra("category", "hotel billing");
            startActivity(intent);
        });
    }

    private void fetchHotelDetails() {
        executorService.execute(() -> {
            try (Connection connection = new connectionclass().conn()) {
                String query = "SELECT * FROM hotel WHERE places_id = ?";
                PreparedStatement statement = connection.prepareStatement(query);
                statement.setInt(1, placeId); // Use placeId to find hotels
                ResultSet rs = statement.executeQuery();
                Log.d("DatabaseQuery", "Executing query with placeId: " + placeId);
                if (rs.next()) {
                    final String hotelId = rs.getString("hotel_id");
                    final String hotelName = rs.getString("hotel_name");
                    final String hotelAddress = rs.getString("address");
                    final String phoneNo = rs.getString("phone_no");
                    final String roomType = rs.getString("room_type");
//                    rate = rs.getDouble("rate");
                    String rateString = rs.getString("rate");
                     rate = Double.parseDouble(rateString.replace(",", ""));

                    Log.d("DatabaseQuery", "Hotel Name: " + hotelName);

                    runOnUiThread(() -> {
                        tvHotelName.setText(hotelName);
                        tvHotelId.setText(String.valueOf(hotelId));
                        tvAddress.setText(hotelAddress);
                        tvPhoneNo.setText(phoneNo);
                        tvRoomType.setText(roomType);
                        tvRate.setText(String.valueOf(rate));
                    });
                } else {
                    runOnUiThread(() ->
                            Toast.makeText(HotelActivity.this, "No hotels found for this place", Toast.LENGTH_SHORT).show()
                    );
                }
            } catch (Exception e) {
                Log.e("DatabaseError", "Error fetching hotel details", e);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executorService.shutdown();
    }
}
