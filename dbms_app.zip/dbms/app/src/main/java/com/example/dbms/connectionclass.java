package com.example.dbms;

import android.util.Log;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Objects;

public class connectionclass {
    protected static String db = "cp_db1";
    protected static String ip = "10.0.2.2";
    protected static String port = "3306";
    protected static String username = "root";
    protected static String password = "Kaus@712&";

    public Connection conn(){
        Connection conn =null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            String connectingString = "jdbc:mysql://"+ip+":"+port +"/"+db;
            conn = DriverManager.getConnection(connectingString,username,password);
        }catch(Exception e ){
            Log.e( "error",Objects.requireNonNull(e.getMessage()) );
        }
        return conn;
    }
}
