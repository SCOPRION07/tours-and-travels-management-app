package com.example.dbms;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    connectionclass connectionclass;
    Connection conn;
    ResultSet rs;
    String str;
    EditText etUsername, etPassword;
    Button btnLogin;
    TextView tvsignup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvsignup = findViewById(R.id.tvsignup);

        connectionclass = new connectionclass();

        // Handle login button click
        btnLogin.setOnClickListener(v -> connect());

        // Handle signup button click
        tvsignup.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SignupActivity.class);
            startActivity(intent);
            finish();
        });
    }

    public void connect() {
        ExecutorService es1 = Executors.newSingleThreadExecutor();
        es1.execute(() -> {
            try {
                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();

                conn = connectionclass.conn();
                if (conn == null) {
                    str = "Error in connection with MYSQL server";
                } else {
                    // Query to check if the user exists
                    String query = "SELECT * FROM user_id WHERE username = ? AND password = ?";
                    PreparedStatement stmt = conn.prepareStatement(query);
                    stmt.setString(1, username);
                    stmt.setString(2, password);

                    rs = stmt.executeQuery();

                    if (rs.next()) {

                        // If user exists, go to next page - HomeActivity
                        int userId = rs.getInt("user_id"); // Retrieve user_id from database

                        // Store user_id in SharedPreferences
                        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putInt("user_id", userId);
                        editor.apply(); // Save the user_id
                        Intent intent = new Intent(MainActivity.this, HomeActivity.class);//                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        finish();
                    } else {
                        str = "Invalid credentials. Please try again.";
                    }
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

            runOnUiThread(() -> Toast.makeText(this, str, Toast.LENGTH_SHORT).show());
        });
    }
}
