package com.example.dbms;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends AppCompatActivity {
    connectionclass connectionclass;
    Connection conn;
    String str;
    EditText usernameEditText, passwordEditText, emailEditText, fullNameEditText, phoneEditText, addressEditText, dobEditText;
    Button signupButton,button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);  // Using activity_signup.xml

        // Initialize views
        usernameEditText = findViewById(R.id.etusernameEditText);
        passwordEditText = findViewById(R.id.etpasswordEditText);
        emailEditText = findViewById(R.id.etEmail);
        fullNameEditText = findViewById(R.id.etfullNameEditText);
        phoneEditText = findViewById(R.id.etphoneEditText);
        addressEditText = findViewById(R.id.etaddressEditText);
        dobEditText = findViewById(R.id.etdobEditText);
        signupButton = findViewById(R.id.signupButton);
        button = findViewById(R.id.button);
        connectionclass = new connectionclass();

        // Handle signup button click
        signupButton.setOnClickListener(v -> registerUser());
        button.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        });
    }
    public void registerUser() {
        ExecutorService es1 = Executors.newSingleThreadExecutor();
        es1.execute(() -> {
            try {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();
                String email = emailEditText.getText().toString();
                String fullName = fullNameEditText.getText().toString();
                String phone = phoneEditText.getText().toString();
                String address = addressEditText.getText().toString();
                String dob = dobEditText.getText().toString();

                if (phone.length() < 10 || Long.parseLong(phone) < 0) {
                    runOnUiThread(() -> Toast.makeText(this, "Phone number must be at least 10 digits and non-negative", Toast.LENGTH_SHORT).show());
                    return;
                }

                conn = connectionclass.conn();
                if (conn == null) {
                    str = "Error in connection with MYSQL server";
                } else {
                    // Check if username already exists
                    String checkUsernameQuery = "SELECT COUNT(*) FROM user_id WHERE username = ?";
                    PreparedStatement checkStmt = conn.prepareStatement(checkUsernameQuery);
                    checkStmt.setString(1, username);
                    ResultSet rs = checkStmt.executeQuery();
                    if (rs.next() && rs.getInt(1) > 0) {
                        runOnUiThread(() -> Toast.makeText(this, "Username already taken. Please choose another.", Toast.LENGTH_SHORT).show());
                        return;
                    }

                    // Insert new user into the database
                    String insertQuery = "INSERT INTO user_id (username, password, email, full_name, phno, address, DOB, Sign_Up_Date) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
                    PreparedStatement stmt = conn.prepareStatement(insertQuery);
                    stmt.setString(1, username);
                    stmt.setString(2, password); // Ensure to hash the password before storing it
                    stmt.setString(3, email);
                    stmt.setString(4, fullName);// if(PHNO <1000000000)
                    stmt.setString(5, phone);
                    stmt.setString(6, address);
                    stmt.setString(7, dob);
                    stmt.executeUpdate();
                    str = "New user registered successfully";

                    // Redirect to login page after signup
                    Intent intent = new Intent(SignupActivity.this, MainActivity.class);
//                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                }
            } catch (Exception e) {
                str = "Error inserting new user: " + e.getMessage();
            }

            runOnUiThread(() -> Toast.makeText(this, str, Toast.LENGTH_SHORT).show());
        });
    }
}
