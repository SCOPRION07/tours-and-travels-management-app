package com.example.dbms;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity2 extends AppCompatActivity {
    private TextView tvPlaceName, tvImageUrl, tvPlaceDescription, tvBestTime, tvAttractions;
    private int placeId; // Make sure placeId corresponds to the passed ID
    private ExecutorService executorService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // Initialize all TextViews
        tvPlaceName = findViewById(R.id.tvPlaceName); // Make sure the layout has this TextView for the place name
        tvImageUrl = findViewById(R.id.tvImageUrl); // TextView for displaying the image URL
        tvPlaceDescription = findViewById(R.id.tvPlaceDescription);
        tvBestTime = findViewById(R.id.tvBestTime);
        tvAttractions = findViewById(R.id.tvAttractions);

        placeId = getIntent().getIntExtra("place_id", -1); // Change key as needed
        executorService = Executors.newSingleThreadExecutor();

        fetchPlaceDetails(); // Fetch place details when activity is created

        findViewById(R.id.btnHotels).setOnClickListener(v -> {
            Intent intent = new Intent(this, HotelActivity.class);
            intent.putExtra("place_id", placeId);
            startActivity(intent);
        });

        findViewById(R.id.btnTransportation).setOnClickListener(v -> {
            Log.d("MainActivity2", "Navigating to TransportationActivity with placeId: " + placeId);
            Intent intent = new Intent(this, TransportationActivity.class);
            intent.putExtra("place_id", placeId);
            startActivity(intent);
        });
    }

    private void fetchPlaceDetails() {
        executorService.execute(() -> {
            Place place = null;
            try (Connection connection = new connectionclass().conn()) { // Use your connection class here
                String query = "SELECT * FROM location WHERE places_id = ?"; // Ensure the column name matches your database
                PreparedStatement statement = connection.prepareStatement(query);
                statement.setInt(1, placeId);
                ResultSet rs = statement.executeQuery();

                if (rs.next()) {
                    place = new Place(
                            rs.getInt("places_id"),
                            rs.getString("place_name"),
                            rs.getString("description"),
                            rs.getString("best_time_to_visit"),
                            rs.getString("popular_attractions"),
                            rs.getString("image_url")
                    );
                }
            } catch (Exception e) {
                Log.e("DatabaseError", "Error fetching place details", e);
            }

            Place finalPlace = place;
            runOnUiThread(() -> {
                if (finalPlace != null) {
                    // Set the place name at the top
                    tvPlaceName.setText(finalPlace.getPlaceName());

                    // Show the image URL as text instead of loading the image
                    tvImageUrl.setText(finalPlace.getImageUrl());

                    // Set other details in respective TextViews
                    tvPlaceDescription.setText(finalPlace.getDescription());
                    tvBestTime.setText(finalPlace.getBestTimeToVisit());
                    tvAttractions.setText(finalPlace.getPopularAttractions());
                } else {
                    Toast.makeText(MainActivity2.this, "Place not found", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executorService.shutdown(); // Shutdown the executor service
    }

    // Place class defined here
    public class Place {
        private int placeId;
        private String placeName;
        private String description;
        private String bestTimeToVisit;
        private String popularAttractions;
        private String imageUrl;

        public Place(int placeId, String placeName, String description, String bestTimeToVisit, String popularAttractions, String imageUrl) {
            this.placeId = placeId;
            this.placeName = placeName;
            this.description = description;
            this.bestTimeToVisit = bestTimeToVisit;
            this.popularAttractions = popularAttractions;
            this.imageUrl = imageUrl;
        }

        // Getters
        public int getPlaceId() { return placeId; }
        public String getPlaceName() { return placeName; }
        public String getDescription() { return description; }
        public String getBestTimeToVisit() { return bestTimeToVisit; }
        public String getPopularAttractions() { return popularAttractions; }
        public String getImageUrl() { return imageUrl; }
    }
}
