package com.example.dbms;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HomeActivity extends AppCompatActivity {
    private Spinner spinnerCountry, spinnerCity, spinnerPlace;
    private Button btnNext,logout;
    private ExecutorService executorService;
    private String selectedPlace;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        spinnerCountry = findViewById(R.id.spinnerCountry);
        spinnerCity = findViewById(R.id.spinnerCity);
        spinnerPlace = findViewById(R.id.spinnerPlace);
        btnNext = findViewById(R.id.btnNext);
        logout = findViewById(R.id.logout);

        // Initialize ExecutorService
        executorService = Executors.newSingleThreadExecutor();

        loadCountries();

        spinnerCountry.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCountry = parent.getItemAtPosition(position).toString();
                loadCities(selectedCountry);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        spinnerCity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCity = parent.getItemAtPosition(position).toString();
                loadPlaces(selectedCity);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });


        final Place[] selectedPlaceObject = {new Place()}; // Change to hold Place object

        spinnerPlace.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedPlaceObject[0] = (Place) parent.getItemAtPosition(position); // Store selected Place object
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });


        btnNext.setOnClickListener(view -> {
            if (selectedPlaceObject[0] != null) { // Check if selectedPlaceObject is not null
                navigateToNextPage(selectedPlaceObject[0]); // Pass the selected Place object
            } else {
                Toast.makeText(this, "Please select a place", Toast.LENGTH_SHORT).show();
            }
        });
        logout.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        });
    }

    private void loadCountries() {
        executorService.execute(() -> {
            List<String> countries = new ArrayList<>();
            try (Connection conn = new connectionclass().conn()) {
                String query = "SELECT DISTINCT country FROM location";
                PreparedStatement stmt = conn.prepareStatement(query);
                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    countries.add(rs.getString("country"));
                }
            } catch (Exception e) {
                Log.e("DatabaseError", "Error loading countries", e);
            }

            runOnUiThread(() -> {
                ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, countries);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerCountry.setAdapter(adapter);
            });
        });
    }

    private void loadCities(String country) {
        executorService.execute(() -> {
            List<String> cities = new ArrayList<>();
            try (Connection conn = new connectionclass().conn()) {
                String query = "SELECT DISTINCT city FROM location WHERE country = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, country);
                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    cities.add(rs.getString("city"));
                }
            } catch (Exception e) {
                Log.e("DatabaseError", "Error loading cities", e);
            }

            runOnUiThread(() -> {
                ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, cities);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerCity.setAdapter(adapter);
            });
        });
    }

private void loadPlaces(String city) {
    executorService.execute(() -> {
        List<Place> places = new ArrayList<>();
        try (Connection conn = new connectionclass().conn()) {
            String query = "SELECT places_id, place_name FROM location WHERE city = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, city);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int placesId = rs.getInt("places_id");
                String placeName = rs.getString("place_name");
                places.add(new Place(placesId, placeName)); // Create a new Place object
            }
        } catch (Exception e) {
            Log.e("DatabaseError", "Error loading places", e);
        }

        runOnUiThread(() -> {
            ArrayAdapter<Place> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, places);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerPlace.setAdapter(adapter);
        });
    });
}

private void navigateToNextPage(Place selectedPlace) {
    Intent intent = new Intent(this, MainActivity2.class);
    intent.putExtra("place_id", selectedPlace.getPlacesId()); // Pass places_id
    startActivity(intent);
}

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executorService.shutdown();
    }
    public class Place {
        private int placesId;
        private String placeName;

        public Place(int placesId, String placeName) {
            this.placesId = placesId;
            this.placeName = placeName;
        }

        public Place() {

        }

        public int getPlacesId() {
            return placesId;
        }

        public String getPlaceName() {
            return placeName;
        }

        @Override
        public String toString() {
            return placeName; // This will be used in the spinner
        }
    }

}
